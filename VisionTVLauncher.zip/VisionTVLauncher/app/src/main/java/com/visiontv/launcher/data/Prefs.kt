package com.visiontv.launcher.data

import android.content.Context

/** تخزين كل الإعدادات محلياً عبر SharedPreferences (أخف خيار للأجهزة الضعيفة). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)

    private fun list(key: String): List<String> =
        (sp.getString(key, "") ?: "").split('\n').filter { it.isNotEmpty() }

    private fun putList(key: String, v: List<String>) {
        sp.edit().putString(key, v.joinToString("\n")).apply()
    }

    private fun putBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }
    private fun putInt(key: String, v: Int) { sp.edit().putInt(key, v).apply() }

    var setupDone: Boolean
        get() = sp.getBoolean("setup_done", false)
        set(v) = putBool("setup_done", v)

    // ---- المظهر ----
    var darkMode: Boolean
        get() = sp.getBoolean("dark", true)
        set(v) = putBool("dark", v)
    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) = putInt("accent", v)
    var background: Int
        get() = sp.getInt("background", 0)
        set(v) = putInt("background", v)
    var iconSize: Int
        get() = sp.getInt("icon_size", 1)
        set(v) = putInt("icon_size", v)
    var cardShape: Int
        get() = sp.getInt("card_shape", 0)
        set(v) = putInt("card_shape", v)
    var animations: Boolean
        get() = sp.getBoolean("anim", true)
        set(v) = putBool("anim", v)

    // ---- الأقسام ----
    var showFavorites: Boolean
        get() = sp.getBoolean("show_fav", true)
        set(v) = putBool("show_fav", v)
    var showRecents: Boolean
        get() = sp.getBoolean("show_recents", true)
        set(v) = putBool("show_recents", v)
    var recentsFirst: Boolean
        get() = sp.getBoolean("recents_first", false)
        set(v) = putBool("recents_first", v)

    // ---- البيانات ----
    var favorites: List<String>
        get() = list("fav")
        set(v) = putList("fav", v)
    var hidden: List<String>
        get() = list("hidden")
        set(v) = putList("hidden", v)
    var order: List<String>
        get() = list("order")
        set(v) = putList("order", v)
    var recents: List<String>
        get() = list("recents")
        set(v) = putList("recents", v)

    fun addRecent(pkg: String) {
        val l = recents.toMutableList()
        l.remove(pkg)
        l.add(0, pkg)
        recents = l.take(12)
    }

    /** بصمة تتغير عندما يلزم إعادة بناء الواجهة بالكامل. */
    fun themeSignature(): String =
        listOf(darkMode, accent, background, iconSize, cardShape, animations, showFavorites, showRecents, recentsFirst)
            .joinToString("|")

    /** بصمة تتغير عندما تتغير القوائم فقط. */
    fun dataSignature(): String =
        listOf(favorites, hidden, order, recents).joinToString("#") { it.joinToString(",") }

    /** إعادة ضبط المظهر فقط (المفضلة والترتيب تبقى). */
    fun resetUi() {
        sp.edit()
            .remove("dark").remove("accent").remove("background").remove("icon_size")
            .remove("card_shape").remove("anim").remove("show_fav").remove("show_recents")
            .remove("recents_first")
            .apply()
    }
}
