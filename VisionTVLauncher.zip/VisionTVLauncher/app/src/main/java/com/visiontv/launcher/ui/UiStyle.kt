package com.visiontv.launcher.ui

import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import com.visiontv.launcher.data.Prefs

/** كل الألوان والأبعاد مشتقة من الإعدادات، بدون صور (ذاكرة أقل). */
class UiStyle(p: Prefs, res: Resources) {
    private val density = res.displayMetrics.density
    fun dp(v: Int): Int = (v * density).toInt()

    val dark = p.darkMode
    val anim = p.animations
    private val bg = BACKGROUNDS[p.background.coerceIn(0, BACKGROUNDS.size - 1)]
    val accent = ACCENTS[p.accent.coerceIn(0, ACCENTS.size - 1)].second

    val textPrimary = if (dark) 0xFFF5F5F7.toInt() else 0xFF1D1D1F.toInt()
    val textSecondary = if (dark) 0xB3F5F5F7.toInt() else 0xB31D1D1F.toInt()
    private val cardColor = if (dark) 0x1FFFFFFF else 0x14000000
    private val cardFocusColor = if (dark) 0x40FFFFFF else 0x26000000

    val iconPx = dp(intArrayOf(56, 72, 96)[p.iconSize.coerceIn(0, 2)])
    val cellPx = iconPx + dp(44)
    private val radius = intArrayOf(dp(24), dp(10), 0)[p.cardShape.coerceIn(0, 2)].toFloat()

    fun cardBg(): Drawable {
        val normal = GradientDrawable().apply {
            cornerRadius = radius
            setColor(cardColor)
        }
        val focused = GradientDrawable().apply {
            cornerRadius = radius
            setColor(cardFocusColor)
            setStroke(dp(3), accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    fun background(): Drawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(
            if (dark) bg.darkTop else bg.lightTop,
            if (dark) bg.darkBottom else bg.lightBottom
        )
    )

    class Bg(val name: String, val darkTop: Int, val darkBottom: Int, val lightTop: Int, val lightBottom: Int)

    companion object {
        val ACCENTS = listOf(
            "أزرق" to 0xFF0A84FF.toInt(),
            "أخضر" to 0xFF30D158.toInt(),
            "برتقالي" to 0xFFFF9F0A.toInt(),
            "وردي" to 0xFFFF375F.toInt(),
            "بنفسجي" to 0xFFBF5AF2.toInt()
        )
        val BACKGROUNDS = listOf(
            Bg("منتصف الليل", 0xFF0B1020.toInt(), 0xFF1B2A49.toInt(), 0xFFEAF0FA.toInt(), 0xFFD3DDF0.toInt()),
            Bg("الغسق", 0xFF1A0F2E.toInt(), 0xFF3D1F5C.toInt(), 0xFFF3EAFB.toInt(), 0xFFE0CEF2.toInt()),
            Bg("الغابة", 0xFF08150F.toInt(), 0xFF14392A.toInt(), 0xFFE8F6EE.toInt(), 0xFFCDE8D8.toInt()),
            Bg("الجمر", 0xFF1E0D0A.toInt(), 0xFF4A1F14.toInt(), 0xFFFBEDE8.toInt(), 0xFFF2D3C8.toInt()),
            Bg("رمادي", 0xFF101012.toInt(), 0xFF2A2A2E.toInt(), 0xFFF2F2F7.toInt(), 0xFFDADAE0.toInt())
        )
        val ICON_SIZES = listOf("صغير", "متوسط", "كبير")
        val SHAPES = listOf("مستدير", "منحنٍ قليلاً", "مربع")
    }
}

/** تكبير ناعم عند التحديد؛ يتوقف تلقائياً إذا أُغلقت الحركات. */
fun View.zoomOnFocus(scale: Float, animated: () -> Boolean) {
    onFocusChangeListener = View.OnFocusChangeListener { v, has ->
        val s = if (has) scale else 1f
        if (animated()) {
            v.animate().scaleX(s).scaleY(s).setDuration(130).start()
        } else {
            v.animate().cancel()
            v.scaleX = s
            v.scaleY = s
        }
        v.translationZ = if (has) 8f else 0f
    }
}
