package com.visiontv.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.visiontv.launcher.data.AppRepository
import com.visiontv.launcher.data.Prefs
import com.visiontv.launcher.ui.Dialogs
import com.visiontv.launcher.ui.UiStyle
import com.visiontv.launcher.ui.zoomOnFocus

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var look: UiStyle
    private lateinit var container: LinearLayout
    private lateinit var header: TextView
    private val rows = ArrayList<Row>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        look = UiStyle(prefs, resources)
        window.setBackgroundDrawable(look.background())

        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(look.dp(120), look.dp(32), look.dp(120), look.dp(32))
        }
        header = TextView(this).apply {
            text = "الإعدادات"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, look.dp(16))
        }
        container.addView(header)
        val scroll = ScrollView(this).apply {
            clipChildren = false
            clipToPadding = false
            addView(container)
        }
        setContentView(scroll)

        buildRows()
        restyleAll()
        rows.firstOrNull()?.view?.requestFocus()
    }

    private fun next(cur: Int, n: Int) = (cur + 1) % n

    private fun buildRows() {
        add("الوضع", { if (prefs.darkMode) "داكن" else "فاتح" }) {
            prefs.darkMode = !prefs.darkMode; restyleAll()
        }
        add("لون الواجهة", { UiStyle.ACCENTS[prefs.accent.coerceIn(0, UiStyle.ACCENTS.size - 1)].first }) {
            prefs.accent = next(prefs.accent, UiStyle.ACCENTS.size); restyleAll()
        }
        add("الخلفية", { UiStyle.BACKGROUNDS[prefs.background.coerceIn(0, UiStyle.BACKGROUNDS.size - 1)].name }) {
            prefs.background = next(prefs.background, UiStyle.BACKGROUNDS.size); restyleAll()
        }
        add("حجم الأيقونات", { UiStyle.ICON_SIZES[prefs.iconSize.coerceIn(0, 2)] }) {
            prefs.iconSize = next(prefs.iconSize, 3)
        }
        add("شكل البطاقات", { UiStyle.SHAPES[prefs.cardShape.coerceIn(0, 2)] }) {
            prefs.cardShape = next(prefs.cardShape, 3); restyleAll()
        }
        add("الحركات (Animations)", { onOff(prefs.animations) }) {
            prefs.animations = !prefs.animations
        }
        add("قسم المفضلة", { onOff(prefs.showFavorites) }) {
            prefs.showFavorites = !prefs.showFavorites
        }
        add("قسم المستخدمة مؤخراً", { onOff(prefs.showRecents) }) {
            prefs.showRecents = !prefs.showRecents
        }
        add("ترتيب الأقسام", { if (prefs.recentsFirst) "المستخدمة مؤخراً أولاً" else "المفضلة أولاً" }) {
            prefs.recentsFirst = !prefs.recentsFirst
        }
        add("اختيار التطبيقات المفضلة") { pickFavorites() }
        add("التطبيقات الظاهرة في الشاشة الرئيسية") { pickVisible() }
        add("تعيين كواجهة رئيسية افتراضية") { Dialogs.openDefaultHomeSettings(this) }
        add("إعدادات النظام (Android)") {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(this, "غير مدعوم على هذا الجهاز", Toast.LENGTH_SHORT).show()
            }
        }
        add("إعادة ضبط المظهر") {
            AlertDialog.Builder(this)
                .setTitle("إعادة ضبط المظهر؟")
                .setMessage("سيتم إرجاع الألوان والحجم والأقسام للوضع الافتراضي. المفضلة والترتيب لن يتغيرا.")
                .setPositiveButton("إعادة ضبط") { _, _ -> prefs.resetUi(); restyleAll() }
                .setNegativeButton("إلغاء", null)
                .show()
        }
    }

    private fun onOff(b: Boolean) = if (b) "مفعّل" else "متوقف"

    private fun pickFavorites() {
        val hidden = prefs.hidden.toSet()
        val apps = AppRepository.load(this).filter { it.pkg !in hidden }
        Dialogs.pickApps(this, "التطبيقات المفضلة", apps, prefs.favorites.toSet()) { sel ->
            val cur = prefs.favorites
            prefs.favorites = cur.filter { it in sel } + sel.filter { it !in cur }
        }
    }

    private fun pickVisible() {
        val apps = AppRepository.load(this)
        val hidden = prefs.hidden.toSet()
        val visible = apps.map { it.pkg }.filter { it !in hidden }.toSet()
        Dialogs.pickApps(this, "التطبيقات الظاهرة", apps, visible) { sel ->
            val known = apps.map { it.pkg }.toSet()
            val newHidden = apps.map { it.pkg }.filter { it !in sel }
            prefs.hidden = newHidden + prefs.hidden.filter { it !in known }
            prefs.favorites = prefs.favorites.filter { it !in newHidden }
            prefs.recents = prefs.recents.filter { it !in newHidden }
        }
    }

    private fun restyleAll() {
        look = UiStyle(prefs, resources)
        window.setBackgroundDrawable(look.background())
        header.setTextColor(look.textPrimary)
        rows.forEach { it.restyle(); it.refresh() }
    }

    private fun add(title: String, value: (() -> String)? = null, action: () -> Unit) {
        val r = Row(title, value, action)
        rows.add(r)
        container.addView(r.view)
    }

    private inner class Row(val rowTitle: String, val valueFn: (() -> String)?, val onClick: () -> Unit) {
        val tTitle = TextView(this@SettingsActivity).apply { textSize = 20f; text = rowTitle }
        val tValue = TextView(this@SettingsActivity).apply { textSize = 18f; gravity = Gravity.END }
        val view = LinearLayout(this@SettingsActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(look.dp(24), look.dp(14), look.dp(24), look.dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = look.dp(8) }
            addView(tTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(tValue, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            setOnClickListener { onClick(); refresh() }
            zoomOnFocus(1.03f) { prefs.animations }
        }

        fun refresh() { tValue.text = valueFn?.invoke() ?: "" }

        fun restyle() {
            tTitle.setTextColor(look.textPrimary)
            tValue.setTextColor(look.accent)
            view.background = look.cardBg()
        }
    }
}
