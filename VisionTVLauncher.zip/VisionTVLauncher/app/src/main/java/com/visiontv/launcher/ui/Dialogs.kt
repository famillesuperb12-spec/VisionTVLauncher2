package com.visiontv.launcher.ui

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import com.visiontv.launcher.data.AppInfo

object Dialogs {
    /** نافذة اختيار متعدد للتطبيقات (تعمل بالريموت). */
    fun pickApps(
        ctx: Context,
        title: String,
        apps: List<AppInfo>,
        initial: Set<String>,
        onOk: (List<String>) -> Unit
    ) {
        val checked = BooleanArray(apps.size) { apps[it].pkg in initial }
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("حفظ") { _, _ ->
                onOk(apps.filterIndexed { i, _ -> checked[i] }.map { it.pkg })
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** يفتح شاشة اختيار الواجهة الرئيسية الافتراضية في النظام. */
    fun openDefaultHomeSettings(ctx: Context) {
        val actions = listOf(
            Settings.ACTION_HOME_SETTINGS,
            Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,
            Settings.ACTION_SETTINGS
        )
        for (a in actions) {
            try {
                ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {
                // جرّب التالي
            }
        }
        Toast.makeText(ctx, "اضغط زر Home في الريموت واختر Vision TV ثم \"دائماً\"", Toast.LENGTH_LONG).show()
    }
}
