package com.visiontv.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** يقرأ التطبيقات الحقيقية المثبتة (Leanback + Launcher العادي). */
object AppRepository {
    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val result = LinkedHashMap<String, AppInfo>()
        val sources = listOf(
            Intent.CATEGORY_LEANBACK_LAUNCHER to true,
            Intent.CATEGORY_LAUNCHER to false
        )
        for ((category, leanback) in sources) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            val found = try {
                pm.queryIntentActivities(intent, 0)
            } catch (e: Exception) {
                emptyList()
            }
            for (ri in found) {
                val ai = ri.activityInfo ?: continue
                val pkg = ai.packageName
                if (pkg == ctx.packageName || result.containsKey(pkg)) continue
                val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
                result[pkg] = AppInfo(pkg, ComponentName(pkg, ai.name), label, leanback, ri)
            }
        }
        return result.values.sortedBy { it.label.lowercase() }
    }
}
