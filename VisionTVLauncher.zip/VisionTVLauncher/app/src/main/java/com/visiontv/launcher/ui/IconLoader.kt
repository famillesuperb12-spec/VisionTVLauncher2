package com.visiontv.launcher.ui

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import com.visiontv.launcher.data.AppInfo
import java.util.concurrent.Executors

/** تحميل الأيقونات عند الحاجة فقط، في خيط واحد، مع كاش صغير. */
class IconLoader(private val pm: PackageManager) {
    private val cache = LruCache<String, Drawable>(120)
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun copyOf(d: Drawable): Drawable = d.constantState?.newDrawable() ?: d

    fun load(app: AppInfo, view: ImageView) {
        view.tag = app.pkg
        val cached = cache.get(app.pkg)
        if (cached != null) {
            view.setImageDrawable(copyOf(cached))
            return
        }
        view.setImageDrawable(null)
        exec.execute {
            val d = try { app.resolve.loadIcon(pm) } catch (e: Exception) { pm.defaultActivityIcon }
            cache.put(app.pkg, d)
            main.post {
                if (view.tag == app.pkg) view.setImageDrawable(copyOf(d))
            }
        }
    }

    fun clear() { cache.evictAll() }
    fun shutdown() { exec.shutdownNow() }
}
