package com.visiontv.launcher.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.visiontv.launcher.R
import com.visiontv.launcher.data.AppInfo

class AppAdapter(
    private val loader: IconLoader,
    private val look: UiStyle,
    private val grid: Boolean,
    private val onOpen: (AppInfo) -> Unit,
    private val onMenu: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: View = v.findViewById(R.id.card)
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    fun indexOf(pkg: String): Int = items.indexOfFirst { it.pkg == pkg }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        v.layoutParams = RecyclerView.LayoutParams(
            if (grid) ViewGroup.LayoutParams.MATCH_PARENT else look.cellPx,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val h = VH(v)
        h.card.background = look.cardBg()
        h.icon.layoutParams = LinearLayout.LayoutParams(look.iconPx, look.iconPx)
        h.label.setTextColor(look.textPrimary)
        v.zoomOnFocus(1.1f) { look.anim }
        v.setOnClickListener { view -> (view.tag as? AppInfo)?.let(onOpen) }
        v.setOnLongClickListener { view ->
            val app = view.tag as? AppInfo
            if (app != null) { onMenu(app, view); true } else false
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = items[position]
        h.itemView.tag = app
        h.label.text = app.label
        if (!h.itemView.hasFocus()) {
            h.itemView.scaleX = 1f
            h.itemView.scaleY = 1f
            h.itemView.translationZ = 0f
        }
        loader.load(app, h.icon)
    }
}
