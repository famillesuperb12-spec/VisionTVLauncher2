package com.visiontv.launcher.data

import android.content.ComponentName
import android.content.pm.ResolveInfo

class AppInfo(
    val pkg: String,
    val component: ComponentName,
    val label: String,
    val leanback: Boolean,
    val resolve: ResolveInfo
)
