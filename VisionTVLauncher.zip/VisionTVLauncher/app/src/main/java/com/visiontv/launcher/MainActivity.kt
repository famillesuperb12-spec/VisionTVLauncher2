package com.visiontv.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.format.DateFormat
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.doOnNextLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.visiontv.launcher.data.AppInfo
import com.visiontv.launcher.data.AppRepository
import com.visiontv.launcher.data.Prefs
import com.visiontv.launcher.ui.AppAdapter
import com.visiontv.launcher.ui.Dialogs
import com.visiontv.launcher.ui.IconLoader
import com.visiontv.launcher.ui.UiStyle
import com.visiontv.launcher.ui.zoomOnFocus
import java.util.Date
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var look: UiStyle
    private lateinit var loader: IconLoader

    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private var allApps: List<AppInfo> = emptyList()
    private var themeSig = ""
    private var dataSig = ""
    private var receiverRegistered = false

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var net: TextView
    private lateinit var settingsBtn: TextView
    private lateinit var hintFav: TextView
    private lateinit var sections: LinearLayout
    private lateinit var sectionFav: View
    private lateinit var sectionRecents: View
    private lateinit var sectionAll: View
    private lateinit var rvFav: RecyclerView
    private lateinit var rvRecent: RecyclerView
    private lateinit var rvAll: RecyclerView
    private lateinit var favAdapter: AppAdapter
    private lateinit var recentAdapter: AppAdapter
    private lateinit var allAdapter: AppAdapter

    private val tick = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 60_000L - System.currentTimeMillis() % 60_000L + 50L)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { reload() }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        look = UiStyle(prefs, resources)
        themeSig = prefs.themeSignature()
        loader = IconLoader(packageManager)

        setContentView(R.layout.activity_main)
        bindViews()
        applyLook()
        buildSections()
    }

    override fun onStart() {
        super.onStart()
        if (prefs.themeSignature() != themeSig) {
            recreate()
            return
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        receiverRegistered = true
        handler.post(tick)
        reload()
    }

    override fun onStop() {
        super.onStop()
        if (receiverRegistered) {
            unregisterReceiver(pkgReceiver)
            receiverRegistered = false
        }
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        loader.shutdown()
        io.shutdownNow()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        loader.clear()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // زر Home ضغط والواجهة مفتوحة: ارجع للأعلى
        rvAll.scrollToPosition(0)
        sections.requestFocus()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // اللانشر لا يُغلق؛ Back يعيدك لأعلى الشاشة
        rvAll.scrollToPosition(0)
        sections.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO) {
            val f = currentFocus
            val app = f?.tag as? AppInfo
            if (app != null && f != null) showOptions(app, f) else openSettings()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_SETTINGS) {
            openSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ setup

    private fun bindViews() {
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        net = findViewById(R.id.net)
        settingsBtn = findViewById(R.id.settingsBtn)
        hintFav = findViewById(R.id.hintFav)
        sections = findViewById(R.id.sections)
        sectionFav = findViewById(R.id.sectionFav)
        sectionRecents = findViewById(R.id.sectionRecents)
        sectionAll = findViewById(R.id.sectionAll)
        rvFav = findViewById(R.id.rvFav)
        rvRecent = findViewById(R.id.rvRecent)
        rvAll = findViewById(R.id.rvAll)
    }

    private fun applyLook() {
        window.setBackgroundDrawable(look.background())
        clock.setTextColor(look.textPrimary)
        date.setTextColor(look.textSecondary)
        hintFav.setTextColor(look.textSecondary)
        listOf(R.id.titleFav, R.id.titleRecent, R.id.titleAll).forEach {
            findViewById<TextView>(it).setTextColor(look.textPrimary)
        }
        settingsBtn.setTextColor(look.textPrimary)
        settingsBtn.background = look.cardBg()
        settingsBtn.zoomOnFocus(1.08f) { look.anim }
        settingsBtn.setOnClickListener { openSettings() }
    }

    private fun buildSections() {
        val span = ((resources.displayMetrics.widthPixels - 2 * look.dp(48)) / look.cellPx).coerceAtLeast(3)

        rvFav.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rvRecent.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rvAll.layoutManager = GridLayoutManager(this, span)
        rvAll.setHasFixedSize(true)
        rvFav.setHasFixedSize(true)
        rvRecent.setHasFixedSize(true)

        favAdapter = AppAdapter(loader, look, false, ::launch, ::showOptions)
        recentAdapter = AppAdapter(loader, look, false, ::launch, ::showOptions)
        allAdapter = AppAdapter(loader, look, true, ::launch, ::showOptions)
        rvFav.adapter = favAdapter
        rvRecent.adapter = recentAdapter
        rvAll.adapter = allAdapter

        // ترتيب الأقسام وإخفاؤها حسب الإعدادات
        val fav = if (prefs.showFavorites) sectionFav else null
        val rec = if (prefs.showRecents) sectionRecents else null
        val order = if (prefs.recentsFirst) listOf(rec, fav, sectionAll) else listOf(fav, rec, sectionAll)
        sections.removeAllViews()
        order.filterNotNull().forEach { sections.addView(it) }
    }

    // ------------------------------------------------------------------ data

    private fun reload() {
        io.execute {
            val apps = try { AppRepository.load(this) } catch (e: Exception) { null }
            handler.post {
                if (apps != null && !isDestroyed) {
                    allApps = apps
                    refreshUi()
                    if (!prefs.setupDone && apps.isNotEmpty()) {
                        prefs.setupDone = true
                        showWelcome()
                    }
                }
            }
        }
    }

    private fun visibleApps(): List<AppInfo> {
        val hidden = prefs.hidden.toSet()
        val visible = allApps.filter { it.pkg !in hidden }
        val order = prefs.order
        if (order.isEmpty()) return visible
        val idx = HashMap<String, Int>()
        order.forEachIndexed { i, p -> idx[p] = i }
        return visible.sortedWith(compareBy<AppInfo> { idx[it.pkg] ?: Int.MAX_VALUE })
    }

    private fun refreshUi() {
        val sig = prefs.dataSignature() + "|" + allApps.joinToString(",") { it.pkg }
        if (sig == dataSig) return
        dataSig = sig

        val focused = currentFocus
        val focusedPkg = (focused?.tag as? AppInfo)?.pkg
        val focusedRv = focused?.parent as? RecyclerView

        val hidden = prefs.hidden.toSet()
        val byPkg = allApps.associateBy { it.pkg }
        val favs = prefs.favorites.filter { it !in hidden }.mapNotNull { byPkg[it] }
        val recents = prefs.recents.filter { it !in hidden }.mapNotNull { byPkg[it] }

        favAdapter.submit(favs)
        recentAdapter.submit(recents)
        allAdapter.submit(visibleApps())

        hintFav.visibility = if (favs.isEmpty()) View.VISIBLE else View.GONE
        rvFav.visibility = if (favs.isEmpty()) View.GONE else View.VISIBLE
        sectionRecents.visibility = if (recents.isEmpty()) View.GONE else View.VISIBLE

        if (focusedPkg != null && focusedRv != null) {
            restoreFocus(focusedRv, focusedPkg)
        } else if (focused == null) {
            val first = listOf(rvFav, rvRecent, rvAll).firstOrNull {
                it.isShown && (it.adapter?.itemCount ?: 0) > 0
            }
            first?.let { rv ->
                rv.doOnNextLayout { rv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
            }
        }
    }

    private fun restoreFocus(rv: RecyclerView, pkg: String) {
        var target = rv
        var pos = (rv.adapter as? AppAdapter)?.indexOf(pkg) ?: -1
        if (pos < 0 || !rv.isShown) {
            target = rvAll
            pos = 0
        }
        if ((target.adapter?.itemCount ?: 0) == 0) return
        val t = target
        val p = pos
        t.doOnNextLayout {
            t.scrollToPosition(p)
            t.doOnNextLayout { t.findViewHolderForAdapterPosition(p)?.itemView?.requestFocus() }
        }
    }

    // ------------------------------------------------------------------ actions

    private fun launch(app: AppInfo) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(if (app.leanback) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER)
                .setComponent(app.component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            val opts = if (look.anim)
                ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            else null
            startActivity(i, opts)
            prefs.addRecent(app.pkg)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر فتح ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showOptions(app: AppInfo, anchor: View) {
        val rv = anchor.parent as? RecyclerView
        val isFav = prefs.favorites.contains(app.pkg)
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); actions.add(a) }

        add("فتح") { launch(app) }
        add(if (isFav) "إزالة من المفضلة" else "إضافة إلى المفضلة") { toggleFavorite(app) }
        if (rv != null && (rv === rvFav || rv === rvAll)) {
            add("تحريك لليسار") { move(app, rv, -1) }
            add("تحريك لليمين") { move(app, rv, 1) }
        }
        add("إخفاء من الشاشة الرئيسية") { hideApp(app) }
        add("معلومات التطبيق") {
            startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        }
        add("إلغاء التثبيت") {
            startSafely(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        }

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun startSafely(i: Intent) {
        try { startActivity(i) } catch (e: Exception) {
            Toast.makeText(this, "غير مدعوم على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleFavorite(app: AppInfo) {
        val f = prefs.favorites.toMutableList()
        if (!f.remove(app.pkg)) f.add(app.pkg)
        prefs.favorites = f
        refreshUi()
    }

    private fun hideApp(app: AppInfo) {
        prefs.hidden = prefs.hidden + app.pkg
        prefs.favorites = prefs.favorites.filter { it != app.pkg }
        prefs.recents = prefs.recents.filter { it != app.pkg }
        Toast.makeText(this, "تم الإخفاء. يمكنك إظهاره من الإعدادات", Toast.LENGTH_LONG).show()
        refreshUi()
    }

    private fun move(app: AppInfo, rv: RecyclerView, delta: Int) {
        if (rv === rvFav) {
            val list = prefs.favorites.toMutableList()
            val i = list.indexOf(app.pkg)
            val j = i + delta
            if (i < 0 || j < 0 || j >= list.size) return
            java.util.Collections.swap(list, i, j)
            prefs.favorites = list
        } else {
            val list = visibleApps().map { it.pkg }.toMutableList()
            val i = list.indexOf(app.pkg)
            val j = i + delta
            if (i < 0 || j < 0 || j >= list.size) return
            java.util.Collections.swap(list, i, j)
            prefs.order = list
        }
        refreshUi()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // ------------------------------------------------------------------ first run

    private fun showWelcome() {
        AlertDialog.Builder(this)
            .setTitle("مرحباً بك في Vision TV")
            .setMessage(
                "سنبدأ باختيار تطبيقاتك المفضلة.\n\n" +
                    "لجعل Vision TV الواجهة الرئيسية: اضغط \"تعيين كافتراضي\" أو اضغط زر Home في الريموت واختر Vision TV ثم \"دائماً\"."
            )
            .setPositiveButton("التالي") { _, _ -> pickFavorites() }
            .setNeutralButton("تعيين كافتراضي") { _, _ -> Dialogs.openDefaultHomeSettings(this) }
            .setNegativeButton("لاحقاً", null)
            .setCancelable(false)
            .show()
    }

    private fun pickFavorites() {
        val hidden = prefs.hidden.toSet()
        val apps = allApps.filter { it.pkg !in hidden }
        Dialogs.pickApps(this, "اختر تطبيقاتك المفضلة", apps, prefs.favorites.toSet()) { sel ->
            val cur = prefs.favorites
            prefs.favorites = cur.filter { it in sel } + sel.filter { it !in cur }
            refreshUi()
        }
    }

    // ------------------------------------------------------------------ status bar

    private fun updateStatus() {
        val now = Date()
        clock.text = DateFormat.getTimeFormat(this).format(now)
        date.text = DateFormat.format("EEEE d MMMM", now)

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try {
            cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        } catch (e: Exception) {
            null
        }
        val text = when {
            caps == null -> "غير متصل"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "متصل"
        }
        net.text = text
        net.setTextColor(if (caps == null) look.textSecondary else look.accent)
    }
}
